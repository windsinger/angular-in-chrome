export declare class Console {
    log(message: string): void;
    warn(message: string): void;
}
